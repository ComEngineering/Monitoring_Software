<script src="script/jquery-1.10.2.min.js"></script>
    <script src="script/jquery-migrate-1.2.1.min.js"></script>
    <script src="script/jquery-ui.js"></script>
    <script src="script/bootstrap.min.js"></script>
    <script src="script/bootstrap-hover-dropdown.js"></script>
    <script src="script/html5shiv.js"></script>
    <script src="script/respond.min.js"></script>
    
    <script src="script/jquery.slimscroll.js"></script>
    <script src="script/jquery.cookie.js"></script>
    <script src="script/icheck.min.js"></script>
    <script src="script/custom.min.js"></script>
    
    
    <script src="script/pace.min.js"></script>
    <script src="script/holder.js"></script>
    <script src="script/responsive-tabs.js"></script>
     
    <script src="script/zabuto_calendar.min.js"></script>
    <script src="script/index.js"></script>
  
        <!-- InputMask -->
    <script src="script/input-mask/jquery.inputmask.js"></script>
    <script src="script/input-mask/jquery.inputmask.date.extensions.js"></script>
    <script src="script/input-mask/jquery.inputmask.extensions.js"></script>
    
    <script src="script/bootstrap-switch.min.js"></script>
    <!--CORE JAVASCRIPT-->
    <script src="script/main.js"></script>
    <script>

    $(function(){
      
       var path = "<?php echo substr($_SERVER['PHP_SELF'],1);?>";
       $(".sidebar-menu .active").removeClass("active");
       $("a[href='"+path+"']").parent().addClass("active").closest(".treeview").addClass("active");
    })
    </script>
</body>
</html>