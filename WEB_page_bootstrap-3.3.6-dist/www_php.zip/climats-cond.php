<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Климатика \ Кондиционер</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Климатика</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Климатика</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div class="row mbl">
    					<ul id="generalTab" class="nav nav-tabs responsive hidden-xs hidden-sm">
                            <li class="active"><a href="#status-tab" data-toggle="tab">Состояния</a></li>
                            <li class=""><a href="#params-tab" data-toggle="tab">Параметры</a></li>
                            <li class=""><a href="#monitor-tab" data-toggle="tab">Монитор событий</a></li>
                        </ul>
                        <div id="generalTabContent" class="tab-content responsive hidden-xs hidden-sm">
                        <div id="status-tab" class="tab-pane fade in active">
                                <div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Температурные датчики кондиционера</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="datchiki-temperaturi-cond">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
                            
							 
                                <div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Состояние систем кондиционера</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="status-system-cond">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
                           		<div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Аварии кондиционера</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="dangers-cond">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
                                 
                                
							</div>
						<div id="params-tab" class="tab-pane fade in ">
							<div class="row">
								<div class="col-md-8">
								<table class="table table-hover table-bordered" id="parametrs-cond">
				                                    <thead>
				                                    	<tr><th colspan="7" class="bggray">Параметрирование кондиционера</th></tr>
				                                    <tr>
				                                    <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    	
				                                    <tr>
				                                    	<td>1</td><td class="active">t внутренняя (С)</td><td>22</td><td>задание внутренней температуры (относительно t3)(min:10, max:40)</td>
				                                    </tr>
				                                    <tr>
				                                    	<td>1</td><td class="active">t внутренняя (С)</td><td>22</td><td>задание внутренней температуры (относительно t3)(min:10, max:40)</td>
				                                    </tr>
				                                    <tr><td colspan="7" class="bggray">Настройка работы вентилятора конденсатора "!!!"</td></tr>
				                                      <tr>
				                                      	<td>1</td><td class="active">t внутренняя (С)</td><td>22</td><td>задание внутренней температуры (относительно t3)(min:10, max:40)</td>
				                                    </tr>
				                                    <tr>
				                                    	<td>1</td><td class="active">t внутренняя (С)</td><td>22</td><td>задание внутренней температуры (относительно t3)(min:10, max:40)</td>
				                                    </tr>
				                                    </tbody>
				                                </table>
							</div>
                                    
							</div>	
                        </div>
						<div id="monitor-tab" class="tab-pane fade in ">
							<div class="row">
							<div class="col-md-8">
								<table class="table table-hover table-bordered" id="status-discrete-in">
				                                    <thead>
				                                    	<tr><th colspan="7" class="bggray">Монитор событий</th></tr>
				                                    <tr>
				                                    <th>№</th><th>Вкл/выкл</th><th>Наименование</th><th>Строгость события</th><th colspan="2">Значения события<br>(меньше/больше)</th><th>Действие</th>
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    	<tr><td colspan="7" class="bggray">Температурные датчики кондиционера</td></tr>
				                                    <tr>
				                                    	<td>1</td><td class="active"><input type="checkbox" name="dt1"></td><td>Dt1</td><td class="success">warning</td><td>-20</td><td>50</td><td>no</td>
				                                    </tr>
				                                    <tr>
				                                    	<td>2</td><td class="active"><input type="checkbox" name="dt1"></td><td>Dt2</td><td class="success">warning</td><td>-20</td><td>50</td><td>no</td>                                      
				                                    </tr>
				                                    </tbody>
				                                </table>
							</div>
							</div>
						</div>


                    </div>
                </div>
</div>                
<script>

	</script>
<?php include "footer.php";?>
