<?php
    
   session_start();
   $user = "adm";
   $pass = "Qweszxc1";
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = stripslashes($_POST['username']);
      $mypassword = stripslashes($_POST['password']); 
      
      // If result matched $myusername and $mypassword, table row must be 1 row
        
      if(isset($_POST['username']) && isset($_POST['password']) && $myusername==$user && $mypassword==$pass) {
         
         $_SESSION['login_user'] = $myusername;
         
         header("location: index.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link type="text/css" rel="stylesheet" href="styles/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="styles/bootstrap.min.css">
    
    <link type="text/css" rel="stylesheet" href="styles/all.css">
    <link type="text/css" rel="stylesheet" href="styles/main.css">
    <link type="text/css" rel="stylesheet" href="styles/style-responsive.css">
</head>
<body style="background:#ccc;">
    <div class="page-form">
        <div class="panel panel-black">
        <div class="panel-heading">Monitoring system</div>
            <div class="panel-body ">
                <form action="login.php" method="post" class="form-horizontal">
                <div class="form-body pal">
                     
                     
                    <div class="form-group">
                        
                        <div class="col-md-12">
                            <div class="input-icon left">
                                <i class="fa fa-user"></i>
                                <input name="username" id="inputName" type="text" placeholder="Login" class="form-control" /></div>
                        </div>
                    </div>
                    <div class="form-group">
                         
                        <div class="col-md-12">
                            <div class="input-icon left">
                                <i class="fa fa-lock"></i>
                                <input name="password" id="inputPassword" type="password" placeholder="Password" class="form-control" /></div>
                        </div>
                    </div>
                    <div class="form-group mbn">
                        <div class="col-lg-12" align="right">
                            <div class="form-group mbn">
                                
                                <div class="col-lg-2">
                                    
                                    <button type="submit" class="btn btn-primary">
                                        Sign In</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
       
    </div>
</body>
</html>
