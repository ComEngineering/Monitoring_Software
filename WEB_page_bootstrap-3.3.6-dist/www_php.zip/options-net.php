<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Настройки / Сеть</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Настройки</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Настройки</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
					
					<div class="row mbl">
						<div class="col-md-5">
							<div class="panel panel-violet">
                                            <div class="panel-heading">
                                                Сеть</div>
                                            <div class="panel-body pan">
                                                <form action="#">
                                                <div class="form-body pal">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                         <label>Физический адрес:</label>    <span id="physica_address">___.____.___.___</span>
                                                            
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-keyboard-o"></i>
                                                                    <input id="ipAddress" type="text" placeholder="IP адрес:" class="form-control" data-inputmask="'alias': 'ip'" data-mask></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-keyboard-o"></i>
                                                                    <input id="maskAddress" type="text" placeholder="Маска подсети" class="form-control" data-inputmask="'alias': 'ip'" data-mask></div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-keyboard-o"></i>
                                                                    <input id="gateway" type="text" placeholder="Шлюз" class="form-control" data-inputmask="'alias': 'ip'" data-mask></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                     
                                                     <div class="row">
                                                        
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-keyboard-o"></i>
                                                                    <input id="DNS1" type="text" placeholder="DNS1" class="form-control" data-inputmask="'alias': 'ip'" data-mask></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-keyboard-o"></i>
                                                                    <input id="DNS2" type="text" placeholder="DNS2" class="form-control" data-inputmask="'alias': 'ip'" data-mask></div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-font"></i>
                                                                    <input id="httpport" type="text" placeholder="HTTP-порт" class="form-control"></div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-font"></i>
                                                                    <input id="httphost" type="text" placeholder="Имя хоста" class="form-control"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                     
                                                    
                                                </div>
                                                 
                                                </form>
                                            </div>
                                        </div>
                    </div>
					</div>
                </div>
</div>      

<?php include "footer.php";?>
<script>
    $("[data-mask]").inputmask();
</script>          
