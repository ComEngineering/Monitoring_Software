<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Обзор системы</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Обзор системы</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Обзор системы</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
					<div class="row mbl">
						<div class="col-md-12">
							<div class="panel panel-violet">
                            <div class="panel-heading">Текущий лог системы</div>
                            <div class="panel-body">
                                <table class="table table-hover table-striped" id="currentSystemLog">
                                    <thead>
                                    <tr>
                                        <th>Дата и время</th>
                                        <th>Источник</th>
                                        <th>Строгость</th>
                                        <th>Событие</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr class="">
                                        <td>20.05.2016 16:12</td>
                                        <td>Модули/Главный модуль</td>
                                        <td><span class="label label-sm label-success">Major</span></td>
                                        <td>Превышение min значения: Dt1</td>
                                    </tr>
                                     
                                    </tbody>
                                </table>
                            </div>
                        </div>
						</div>
					</div>
					<div class="row mbl">
						<div class="col-md-8">
							<div class="panel panel-green">
                            <div class="panel-heading">Информация о системе:</div>
                            <div class="panel-body">
                                <table class="table table-hover table-striped" id="systemInfo">
                                    <thead>
                                    
                                    </thead>
                                    <tbody>
                                    <tr >
                                        <td>Дата/время </td>
                                        <td>21.05.2016</td>
                                        
                                    </tr>
                                     
                                    </tbody>
                                </table>
                            </div>
                        </div>
						</div>
					</div>
                </div>
</div>                
<?php include "footer.php";?>
