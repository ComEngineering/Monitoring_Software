<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Логи</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Логи</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Логи</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
					
					<div class="row mbl">
						<div class="col-md-8">
							<div class="panel"> 
                                <table class="table table-hover table-bordered" id="system-power">
                                    <thead>
                                        <tr class="bggray"><th></th><th>Дата и время</th><th>Источник</th><th>Строгость</th><th>Событие</th></tr>
                                    </thead>
                                    <tbody>
                                    <tr >
                                        <td>1</td>
                                        <td></td>
                                        <td></td>
                                        
                                    </tr>
                                     
                                    </tbody>
                                </table>
                                <div class="row-fluid"><div class="col-md-12">
                                <ul class="pagination mtm mbm" id="pagination">
                                            <li class="disabled"><a href="#">«</a></li>
                                            <li class="active"><a href="#">1</a></li>
                                            <li><a href="#">2</a></li>
                                            <li><a href="#">3</a></li>
                                            <li><a href="#">4</a></li>
                                            <li><a href="#">5</a></li>
                                            <li><a href="#">»</a></li>
                                        </ul>
                                    </div>
                                    </div>
                            </div>       
                    </div>
					</div>
                </div>
</div>                
<?php include "footer.php";?>
