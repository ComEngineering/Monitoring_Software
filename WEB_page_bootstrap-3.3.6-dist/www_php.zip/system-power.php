<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Система питания</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Система питания</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Система питания</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
					
					<div class="row mbl">
						<div class="col-md-8">
							<div class="panel"> 
                                <table class="table table-hover table-bordered" id="system-power">
                                    <thead>
                                        <tr class="bggray"><th>№</th><th>Параметр</th><th>Значение</th></tr>
                                    </thead>
                                    <tbody>
                                    <tr >
                                        <td>1</td>
                                        <td></td>
                                        <td></td>
                                        
                                    </tr>
                                     
                                    </tbody>
                                </table>
                            </div>       
                    </div>
					</div>
                </div>
</div>                
<?php include "footer.php";?>
