<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Настройки / ModBus</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Настройки</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Настройки</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
					
					<div class="row mbl">
						<div class="col-md-5">
							<div class="panel panel-violet">
                                            <div class="panel-heading">
                                                ModBus</div>
                                            <div class="panel-body pan">
                                                <form action="#" class="form-horizontal">
                                                <div class="form-body pal">
                                                    <div class="form-group">
                                                         <label for="inputName" class="col-md-4 control-label">
                                                            Скорость:</label>
                                                        <div class="col-md-8">
                                                            
                                                            <select class="form-control" id="portSpeed">
                                                            <option>9600</option>
                                                            <option value="9600">9600</option>
                                                            <option value="4096">4096</option>
                                                            <option value="2048">2048</option>
                                                             </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                         <label for="inputName" class="col-md-4 control-label">
                                                            Количество бит данных:</label>
                                                        <div class="col-md-8">
                                                            <div class="radio">
                                                            <label class="radio-inline">
                                                                <input id="options8bit" type="radio" name="optionsbit" value="7 bit" checked="checked" />&nbsp;
                                                                7 бит</label><label class="radio-inline"><input id="options8bit" type="radio"
                                                                    name="optionsbit" value="8 bit" />&nbsp; 8 бит</label> </div>

                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                         <label for="inputName" class="col-md-4 control-label">
                                                            Паритет:</label>
                                                        <div class="col-md-8">
                                                            <div class="radio">
                                                            <label class="radio-inline">
                                                                <input id="optionsnone" type="radio" name="optionsparitet" value="none" checked="checked" />&nbsp;
                                                                none</label><label class="radio-inline"><input id="optionsodd" type="radio"
                                                                    name="optionsparitet" value="odd" />&nbsp; odd</label><label class="radio-inline"><input id="optionseven" type="radio"
                                                                    name="optionsparitet" value="even" />&nbsp; even</label></div>

                                                        </div>
                                                    </div>
                                                     <div class="form-group">
                                                         <label for="inputName" class="col-md-4 control-label">
                                                            Количество стоп бит:</label>
                                                        <div class="col-md-8">
                                                            <div class="radio">
                                                             <label class="radio-inline"><input id="options1stop" type="radio"
                                                                    name="optionsStopBit" value="1" />&nbsp; 1</label><label class="radio-inline"><input id="options2stop" type="radio"
                                                                    name="optionsStopBit" value="2" />&nbsp; 2</label></div>

                                                        </div>
                                                    </div>
                                                </div>
                                                 
                                                </form>
                                            </div>
                                        </div>
                    </div>
					</div>
                </div>
</div>                
<?php include "footer.php";?>
