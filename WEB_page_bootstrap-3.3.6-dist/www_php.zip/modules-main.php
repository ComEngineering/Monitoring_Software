<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Модули \ Главный модуль</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Модули</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Модули</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div class="row mbl">
    					<ul id="generalTab" class="nav nav-tabs responsive hidden-xs hidden-sm">
                            <li class="active"><a href="#status-tab" data-toggle="tab">Состояния</a></li>
                            <li class=""><a href="#params-tab" data-toggle="tab">Параметры</a></li>
                            <li class=""><a href="#monitor-tab" data-toggle="tab">Монитор событий</a></li>
                        </ul>
                        <div id="generalTabContent" class="tab-content responsive hidden-xs hidden-sm">
                        <div id="status-tab" class="tab-pane fade in active">
                                <div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Датчики температуры</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="datchiki-temperaturi">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
                            
							 
                                <div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Состояние дискретных входов</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="status-discrete-in">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
                           		<div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Состояние входов сухих контактов</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="status-in-dry-contacts">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Состояние выходов сигнальных сухих контактов</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="status-out-signal-dry-contacts">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12"> 
                                    	<div class="panel panel-grey">
				                            <div class="panel-heading">Состояние выходов силовых сухих контактов</div>
				                            <div class="panel-body">
				                                <table class="table table-hover table-bordered" id="status-out-silovih-dry-contacts">
				                                    <thead>
				                                    <tr>
				                                        <th>№</th><th>Наименование</th><th>Значение</th><th>Комментарий</th>                                       
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt1</td><td class="success">24.0</td><td class="warning">Верх отсека активного оборудования</td>                                       
				                                    </tr>
				                                    <tr>
				                                        <td>1</td><td class="active">Dt2</td><td class="success">22.5</td><td class="warning">Низ отсека активного оборудования</td>                                       
				                                    </tr>
				                                    </tbody>
				                                </table>
				                            </div>
				                        </div>
                                    </div>
                                </div>
							</div>
						<div id="params-tab" class="tab-pane fade in ">
							
							<div class="row"><div class="col-md-12"><h2>Ручное управление реле</h2></div></div>
							<div class="row">

                                    <div class="col-lg-4"> 
                                    	
                                    	 <form action="#" class="form-horizontal">
                                    	  <div class="form-body pal">

				                                <table class="table table-hover " id="rele-signal">
				                                    <thead>
				                                    <tr>
				                                        <th> </th><th></th><th>Сигнальные</th>
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>SDO 1</td><td class="active" width="50px"><div class="row-fluid"><div class="col-md-12">
				                                        <div class="form-group mbn">
                                                           <div class="checkbox">
                                                                <label>
                                                                    <input tabindex="5" type="checkbox"  /></label></div>
                                                                </div></div></div>
														</td><td><input type="checkbox" name="great" class="switch" data-on-text="Opened" data-off-text="Closed"></td>                                       
				                                    </tr>
				                                  
				                                    </tbody>
				                                </table>
				                            </div>
				                            </form>
                                </div>
                                <div class="col-lg-4"> 
                                     
                                    	 <form action="#" class="form-horizontal">
                                    	  <div class="form-body pal">

				                                <table class="table table-hover " id="rele-silovie">
				                                    <thead>
				                                    <tr>
				                                        <th> </th><th></th><th>Силовые</th>
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    <tr>
				                                        <td>PDO 1</td><td class="active" width="50px"><div class="row-fluid"><div class="col-md-12">
				                                        <div class="form-group mbn">
                                                           <div class="checkbox">
                                                                <label>
                                                                    <input tabindex="5" type="checkbox"  /></label></div>
                                                                </div></div></div>
														</td><td><input type="checkbox" name="great" class="switch" data-on-text="Opened" data-off-text="Closed"></td>                                       
				                                    </tr>
				                                  
				                                    </tbody>
				                                </table>
				                            </div>
				                            </form>
                                </div>
						</div>	
                        </div>
						<div id="monitor-tab" class="tab-pane fade in ">
							<div class="row">
							<div class="col-md-8">
								<table class="table table-hover table-bordered" id="status-discrete-in">
				                                    <thead>
				                                    	<tr><th colspan="7" class="bggray">Монитор событий</th></tr>
				                                    <tr>
				                                    <th>№</th><th>Вкл/выкл</th><th>Наименование</th><th>Строгость события</th><th colspan="2">Значения события<br>(меньше/больше)</th><th>Действие</th>
				                                    </tr>
				                                    </thead>
				                                    <tbody>
				                                    	<tr><td colspan="7" class="bggray">Температурные датчики</td></tr>
				                                    <tr>
				                                    	<td>1</td><td class="active"><input type="checkbox" name="dt1"></td><td>Dt1</td><td class="success">warning</td><td>-20</td><td>50</td><td>no</td>
				                                    </tr>
				                                    <tr>
				                                    	<td>2</td><td class="active"><input type="checkbox" name="dt1"></td><td>Dt2</td><td class="success">warning</td><td>-20</td><td>50</td><td>no</td>                                      
				                                    </tr>
				                                    </tbody>
				                                </table>
							</div>
							</div>
						</div>


                    </div>
                </div>
</div>                
<script>

	</script>
<?php include "footer.php";?>
