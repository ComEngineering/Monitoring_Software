<?php include "header.php";?>
<div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Настройки / Время</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Главная</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Настройки</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Настройки</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
					
					<div class="row mbl">
						<div class="col-md-5">
							<div class="panel panel-violet">
                                            <div class="panel-heading">
                                                Время</div>
                                            <div class="panel-body pan">
                                                <form action="#" class="form-horizontal">
                                                <div class="form-body pal">
                                                    <div class="form-group">
                                                         <label for="inputName" class="col-md-4 control-label">
                                                            Часовой пояс:</label>
                                                        <div class="col-md-8">
                                                            
                                                            <select class="form-control" id="time">
                                                            <option>UTC+2</option>
                                                             
                                                             </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                         <label for="sysDate" class="col-md-4 control-label">
                                                            Дата:</label>
                                                        <div class="col-md-8">
                                                            
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-calendar"></i>
                                                                    <input id="sysDate" type="text" placeholder="" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask=""></div>
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                         <label for="sysTime" class="col-md-4 control-label">
                                                            Время:</label>
                                                        <div class="col-md-8">
                                                            
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <input id="sysTime" type="text" placeholder="" class="form-control" data-inputmask="'alias': 'hh:mm'" data-mask=""></div>
                                                           
                                                        </div>
                                                    </div>
                                                      <div class="form-group">
                                                         <label for="sysSyncNTP" class="col-md-4 control-label">
                                                            Синхронизация по NTP:</label>
                                                        <div class="col-md-8">
                                                            
                                                                <div class="input-icon right">
                                                                   <input type="checkbox" name="sysSyncNTP" id="sysSyncNTP" class="switch">
                                                                </div>
                                                           
                                                        </div>
                                                    </div> 
                                                    <div class="form-group">
                                                         <label for="addressNTP" class="col-md-4 control-label">
                                                            Адрес сервера NTP:</label>
                                                        <div class="col-md-8">
                                                            
                                                                <div class="input-icon right">
                                                                    <i class="fa fa-text"></i>
                                                                    <input id="addressNTP" type="text" placeholder="" class="form-control"></div>
                                                           
                                                        </div>
                                                    </div>
                                                     <div class="form-group">
                                                         <label for="intervalSync" class="col-md-4 control-label">
                                                            Интервал синхронизации:</label>
                                                        <div class="col-md-8">
                                                            
                                                            <select class="form-control" id="intervalSync">
                                                            <option>1 день</option>
                                                             
                                                             </select>
                                                        </div>
                                                    </div>

                                                </div>
                                                 
                                                </form>
                                            </div>
                                        </div>
                    </div>
					</div>
                </div>
</div>                
<?php include "footer.php";?>
<script>
    $("[data-mask]").inputmask();
</script>          
