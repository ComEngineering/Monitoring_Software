
Which file to download?

� If you are upgrading from PowerSuite 2vX or 3vX to PowerSuite 3.6.1,

	Download and install the 42.9MB file:
	<ps_PowerSuite-3v6-1_Installation-Files_(upgrade-from-v2,v3).zip>


� If you are upgrading from PowerSuite 1vX to PowerSuite 3.6.1,
	OR
	If it is the first time you install PowerSuite
	OR
	In any case, just to be sure that you install every component,

	Download the 65.8MB file:
	<ps_PowerSuite-3v6-1_Installation-Files_(Full).zip>


The file 
<ps_PowerSuite-3v6-1_Installation-Files_(upgrade-from-v2,v3).zip> 
contains PowerSuite 3.6.1 installation files without the <.Net> components. 

Notice: 
The PowerSuite 3.6.1 software will only run on computers that have the �.Net� v2.0 components already installed!



manuel.fernandez@eltek.com 

04.01.2016
